import pandas as pd
import numpy as np

# 讀取 CSV 文件
df = pd.read_csv('modified_data.csv')

# 打印原始數據
print("原始數據：")
print(df)

# 創建一個函數來安全地提取日期的最後兩位數字
def extract_day(date_str):
    if pd.isna(date_str) or not isinstance(date_str, str):
        return np.nan
    try:
        return int(date_str[-2:])
    except ValueError:
        return np.nan

# 應用函數並創建掩碼
df['day'] = df['date'].apply(extract_day)
mask = df['day'].notna() & (df['day'] >= 27)

# 使用掩碼篩選數據
df_filtered = df[mask]

# 刪除臨時的 'day' 列
df_filtered = df_filtered.drop('day', axis=1)

# 打印篩選後的數據
print("\n篩選後的數據：")
print(df_filtered)

# 如果需要，可以將篩選後的數據保存回 CSV 文件
df_filtered.to_csv('filtered_data.csv', index=False)