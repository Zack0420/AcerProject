# # import_script.py
import csv
from models import Lion  # 注意这里的模型名应该使用大写开头的形式
import os
import django

# 设置环境变量 DJANGO_SETTINGS_MODULE
os.environ.setdefault('DJANGO_SETTINGS_MODULE', '.mysite.settings')

# 配置 Django
django.setup()


def import_data_from_csv(file_path):
    with open(file_path, 'r') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        for row in csv_reader:
            lion_instance = Lion(
                no=row['no'],
                company_name=row['company_name'],  # 通常使用小写字母加下划线的形式来命名字段
                area=row['area'],
                title=row['title'],
                url=row['url'],
                trip_type=row['trip_type'],
                from_date=row['from_date'],  # 同样使用小写字母加下划线的形式
                trip_number=row['trip_number'],
                group_total=row['group_total'],
                saleable=row['saleable'],
                after_saleable=row['after_saleable'],
                group_state=row['group_state'],
                traffic_information=row['traffic_information'],
                trip_information=row['trip_information'],
                total_date=row['total_date'],
                price=row['price'],
                hotel=row['hotel'],
            )
            lion_instance.save()

if __name__ == '__main__':
    csv_file_path = r'C:\Users\user\Desktop\trip_django\mysite\all.csv'
    import_data_from_csv(csv_file_path)