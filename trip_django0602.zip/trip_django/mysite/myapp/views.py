from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpResponseBadRequest
from datetime import datetime
import sqlite3
import csv
from .models import Lion
from .forms import PriceRangeForm, Area




# Create your views here.
def hello(request,num):
    text = "<h1>12345</h1>"
    return HttpResponse(eval(num)+300)

def number_show(request):
    # num = request.GET.get("num") #這個可以show none
    num = request.GET["num"]
    return HttpResponse(num)

def bmi(request):
    weight = eval(request.GET["weight"])
    height = eval(request.GET["height"])
    bmi = weight / ((height/100)**2)
    return HttpResponse(f"{bmi:.2f}")

def hello_render(request):
    return render(request, 'hello.html', {})

def bmi_render(request):
    weight = eval(request.GET["weight"])
    height = eval(request.GET["height"])
    bmi = weight / ((height/100)**2)
    return render(request, 'hello.html', {"wei":weight,"hei":height,"bmi":f"{bmi:.2f}"})

def bmi_render_locals(request):
    weight = eval(request.GET["weight"])
    height = eval(request.GET["height"])
    bmi = f"{weight / ((height/100)**2):.2f}"
    return render(request, 'hello.html',locals())

def bmi(request):
    today = datetime.now()
    weight = eval(request.GET["weight"])
    height = eval(request.GET["height"])
    bmi = f"{weight / ((height/100)**2):.2f}"
    return render(request, 'bmi.html',locals())

def nine_nine_table(request):
    # number1 = eval(request.GET["number1"])
    # number2 = eval(request.GET["number2"])
    # results = []
    # for i in range(2,number1):
    #     for j in range(2,number2):
    #         ans = i*j
    #         results.append(ans)
    # return render(request,"hello.html",{'number1':number1,'number2':number2,'results':results})
    row = eval(request.GET["row"])
    rows = [num+1 for num in range(row)]

    col = eval(request.GET["col"])
    cols = [num+1 for num in range(col)]

    results = []
    for r in rows:
        results.append([])
        for c in cols:
            results[r-1].append((r) * (c))
    return render(request,"nine_nine_table.html",{'rows':rows,'cols':cols,'results':results})

#csv轉db
def import_data_from_csv(request):
    csv_file_path = r'C:\Users\user\Desktop\trip_django\mysite\all.csv'
    with open(csv_file_path, 'r') as csv_file:
        csv_reader = csv.DictReader(csv_file)

        for row in csv_reader:
            price_str = row['price'].replace(',', '')  # 移除逗号
            lion_instance = Lion(
                no = row['no'],
                company_Name = row['company_Name'],  # 通常使用小写字母加下划线的形式来命名字段
                area = row['area'],
                title = row['title'],
                url = row['url'],
                trip_type = row['trip_type'],
                fromDate = row['fromDate'],  # 同样使用小写字母加下划线的形式
                trip_number = row['trip_number'],
                group_total = row['group_total'],
                saleable = row['saleable'],
                after_saleable = row['after_saleable'],
                group_state = row['group_state'],
                traffic_information = row['traffic_information'],
                trip_information = row['trip_information'],
                total_Date = row['total_Date'],
                # price = row['price'],
                price = price_str,
                hotel = row['hotel'],
            )
            lion_instance.save()

    return HttpResponse("新增成功")

def trip_all(request):
    # # 檢查 "search" 參數是否存在
    # if "search" not in request.GET:
    #     return HttpResponseBadRequest("Missing 'search' parameter")
    # 連接到 SQLite 資料庫
    try:
        conn = sqlite3.connect(r'C:\Users\user\Desktop\trip_django\mysite\db.sqlite3')
        cursor = conn.cursor()
    except sqlite3.Error as e:
        return HttpResponseBadRequest(f"Database connection failed: {e}")


    # 安全地構建 SQL 查詢
    # search = request.GET["search"]
    try:
        # 使用 parameterized query 防止 SQL 注入
        # cursor.execute(f'SELECT {search} FROM Lion where after_saleable = "報名" ' , )
        cursor.execute(f'SELECT * FROM Lion where after_saleable = "報名" ' , )
        rows = cursor.fetchall()
    except sqlite3.Error as e:
        conn.close()
        return HttpResponseBadRequest(f"SQL query failed: {e}")

    # 關閉連線
    conn.close()

# 準備資料以供模板使用
    data = []
    no = []
    url = []
    title = []
    from_Date = []
    price = []

    for row in rows:
        data.append(row)

    for n in range(len(data)): #編號
        no.append(data[n][0])

    for t in range(len(data)): #標題
        title.append(data[t][3])

    for u in range(len(data)): #網址
        url.append(data[u][4])

    for fd in range(len(data)): #出發日期
        from_Date.append(data[fd][6])

    for p in range(len(data)): #價格
        price.append(data[p][15])

    all_data = list(zip(no, title, url, from_Date, price))

    # 渲染模板並傳遞資料
    # return render(request, "trip_all.html", {"search": search ,"all_data":all_data})
    return render(request, "trip_all.html", {"all_data":all_data})


def test(request):
    # # 獲取所有資料ORM
    # lions = Lion.objects.all()
    # res = "print all results in DB:<br>"
    # for lion in lions:
    #     res += lion.no+ ".  "+ lion.title + str(lion.price) + "<br>"
    # return HttpResponse(res)
    # # 資料庫語法
    # try:
    #     res = "print all results in DB:<br>"
    #     conn = sqlite3.connect(r'C:\Users\user\Desktop\trip_django\mysite\db.sqlite3')
    #     rows = conn.execute('SELECT * FROM Lion where after_saleable = "報名"')
    #     for row in rows:
    #         # print(row)
    #             res += str(row[1])+ "." + str(row[3]) + str(row[4]) + str(row[5]) + str(row[17]) + "<br>"
    # #     cursor = conn.cursor()
    # except sqlite3.Error as e:
    #     return HttpResponseBadRequest(f"Database connection failed: {e}")
    # conn.close()
    # return HttpResponse(res)
    try:
        res = "print all results in DB:<br>"
        conn = sqlite3.connect(r'C:\Users\user\Desktop\trip_django\mysite\db.sqlite3')
        rows = conn.execute('SELECT * FROM Lion where after_saleable = "報名" ')
        for row in rows:
            # print(row)
                res += str(row[1])+ "." + str(row[3]) + str(row[4]) + str(row[5]) + str(row[17]) + "<br>"
    #     cursor = conn.cursor()
    except sqlite3.Error as e:
        return HttpResponseBadRequest(f"Database connection failed: {e}")
    conn.close()
    return HttpResponse(res)


# #比價成功
def price(request):
    results_between_prices = []

    if request.method == 'POST':
        form = PriceRangeForm(request.POST)
        if form.is_valid():
            price1 = form.cleaned_data['price1']
            price2 = form.cleaned_data['price2']

            # 确保 price1 小于 price2
            if price1 > price2:
                price1, price2 = price2, price1

            results_between_prices = Lion.objects.filter(price__gt=price1, price__lt=price2)
    else:
        form = PriceRangeForm()

    return render(request, 'compare_prices.html', {
        'form': form,
        'results_between_prices': results_between_prices,
    })

def compare_prices(request): #價格區間
    results_between_prices = []

    if request.method == 'POST':
        form = PriceRangeForm(request.POST)
        if form.is_valid():
            price1 = form.cleaned_data['price1']
            price2 = form.cleaned_data['price2']

            # 确保 price1 小于 price2
            if price1 > price2:
                price1, price2 = price2, price1

            results_between_prices = Lion.objects.filter(price__gt=price1, price__lt=price2)
    else:
        form = PriceRangeForm()

    return render(request, 'front_end/home.html', {
        'form': form,
        'results_between_prices': results_between_prices,
    })

# def area(request): #地區分類
#     results_city = []
#     if request.method == 'POST':
#         form = Area(request.POST)
#         if form.is_valid():
#             city = form.cleaned_data['city']
#             results_city  = Lion.objects.filter(area=city)
#     else:
#         form = Area()

#     return render(request, 'front_end/area.html', {
#         'form': form,
#         'results_city': results_city,
#     })

# def area(request): #地區分類
#     city = request.GET["city"]
#     results_city  = Lion.objects.filter(area=city)
#     selected_options = request.POST.getlist('options')


#     selected_options_List = []

#     for options in selected_options:
#         try:
#             selected_options_List.append(int(options))
#         except ValueError:
#         # 可以在这里处理无法转换为整数的选项值
#             pass

#     results_between_prices = []
#     if request.method == 'POST':
#         form = PriceRangeForm(request.POST)
#         if form.is_valid():
#             price1 = form.cleaned_data['price1']
#             price2 = form.cleaned_data['price2']

#             # 确保 price1 小于 price2
#             if price1 > price2:
#                 price1, price2 = price2, price1
#             results_between_prices = Lion.objects.filter(area=city).filter(price__gt=price1, price__lt=price2).order_by('price')


#     else:
#         form = PriceRangeForm()
#     return render(request, 'front_end/area.html', {"city":city,'form': form,'results_city': results_city,"results_between_prices":results_between_prices,"selected_options":selected_options})



def trip_home(request):
     return render(request, 'front_end/home.html')



def checkbox_view(request):
    if request.method == 'POST':
        selected_options = request.POST.getlist('options')
        # 这里你可以处理选中的复选框值
        # 例如，你可以将它们打印出来或者存储在数据库中
        return HttpResponse(f"Selected options: {', '.join(selected_options)}")
    return render(request, 'test.html')


def area(request): #地區分類
    city = request.GET["city"]
    results_city  = Lion.objects.filter(area=city)
    results_between_prices = []
    if request.method == 'GET':
        search_result_all_item = Lion.objects.filter(area=city).order_by('price')
    else:
        search_result_all_item = []

    selected_options = request.POST.getlist('options')
    if selected_options:
        # 将选项的值转换为整数
        selected_options = [int(option) for option in selected_options]

    if request.method == 'POST':
        form = PriceRangeForm(request.POST)
        if form.is_valid():
            price1 = form.cleaned_data['price1']
            price2 = form.cleaned_data['price2']
            # day = form.cleaned_data['day']

            # 确保 price1 小于 price2
            if price1 > price2:
                price1, price2 = price2, price1
            results_between_prices = Lion.objects.filter(area=city).filter(price__gt=price1, price__lt=price2).order_by('price')
            # results_between_prices = Lion.objects.filter(area=city).filter(total_Date=day).filter(price__gt=price1, price__lt=price2).order_by('price')


    else:
        form = PriceRangeForm()
    return render(request, 'front_end/searchresult.html', {"city":city,'form': form,'results_city': results_city,
                                                           "search_result_all_item":search_result_all_item,"results_between_prices":results_between_prices,"selected_options":selected_options,
                                                           })

