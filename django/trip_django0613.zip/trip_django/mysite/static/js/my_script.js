// my_script.js

$(document).ready(function(){
    $("#my_button").click(function(){
        // 使用 jQuery 抓取 div 的值並輸出到網頁上
        var divValue = $("#output_div").text();
        alert("Div 的值是：" + divValue);
    });
});
