import os
import pandas as pd
from datetime import datetime


current_datetime = datetime.now()
formatted_datetime = current_datetime.strftime('%Y-%m-%d %H:%M:%S').split(" ")[0]

# 指定資料夾路徑
folder_path = r"C:\Users\user\ctest\acerProject0610\mysite\trip\csv"

# 創建一個空的DataFrame來存放合併後的數據
combined_df = pd.DataFrame()

# 遍歷資料夾內的所有CSV檔案
for filename in os.listdir(folder_path):
    if filename.endswith(".csv"):
        # 構造完整的檔案路徑
        file_path = os.path.join(folder_path, filename)
        
        # 讀取CSV檔案
        df = pd.read_csv(file_path)
        
        # 將DataFrame垂直合併到combined_df
        combined_df = pd.concat([combined_df, df], ignore_index=True)

# 創建combined目錄
combined_folder_path = os.path.join(folder_path, "combined")
os.makedirs(combined_folder_path, exist_ok=True)

# 將合併後的DataFrame儲存為新的CSV檔案
combined_file_path = os.path.join(combined_folder_path, f"{formatted_datetime}_combined_data.csv")
combined_df.to_csv(combined_file_path, index=False, encoding='utf-8')
print(f"CSV檔案已合併完成並儲存為 {combined_file_path}")