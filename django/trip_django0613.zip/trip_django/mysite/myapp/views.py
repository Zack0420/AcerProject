from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.http import HttpResponseBadRequest
from django.core.paginator import Paginator
from datetime import datetime
import sqlite3
import csv
from .models import Lion, Trip, Lion_save
from .forms import PriceRangeForm, submitForm
import pandas as pd
import numpy as np




# Create your views here.
def hello(request,num):
    text = "<h1>12345</h1>"
    return HttpResponse(eval(num)+300)

def number_show(request):
    # num = request.GET.get("num") #這個可以show none
    num = request.GET["num"]
    return HttpResponse(num)

def bmi(request):
    weight = eval(request.GET["weight"])
    height = eval(request.GET["height"])
    bmi = weight / ((height/100)**2)
    return HttpResponse(f"{bmi:.2f}")

def hello_render(request):
    return render(request, 'hello.html', {})

def bmi_render(request):
    weight = eval(request.GET["weight"])
    height = eval(request.GET["height"])
    bmi = weight / ((height/100)**2)
    return render(request, 'hello.html', {"wei":weight,"hei":height,"bmi":f"{bmi:.2f}"})

def bmi_render_locals(request):
    weight = eval(request.GET["weight"])
    height = eval(request.GET["height"])
    bmi = f"{weight / ((height/100)**2):.2f}"
    return render(request, 'hello.html',locals())

def bmi(request):
    today = datetime.now()
    weight = eval(request.GET["weight"])
    height = eval(request.GET["height"])
    bmi = f"{weight / ((height/100)**2):.2f}"
    return render(request, 'bmi.html',locals())

def nine_nine_table(request):
    # number1 = eval(request.GET["number1"])
    # number2 = eval(request.GET["number2"])
    # results = []
    # for i in range(2,number1):
    #     for j in range(2,number2):
    #         ans = i*j
    #         results.append(ans)
    # return render(request,"hello.html",{'number1':number1,'number2':number2,'results':results})
    row = eval(request.GET["row"])
    rows = [num+1 for num in range(row)]

    col = eval(request.GET["col"])
    cols = [num+1 for num in range(col)]

    results = []
    for r in rows:
        results.append([])
        for c in cols:
            results[r-1].append((r) * (c))
    return render(request,"nine_nine_table.html",{'rows':rows,'cols':cols,'results':results})

#csv轉db
def import_data_from_csv(request):
    # csv_file_path = r'C:\Users\user\Desktop\trip_django\mysite\all.csv'
    csv_file_path = r'C:\Users\user\Desktop\trip_django\mysite\liontrip_0611all.csv'

    # 使用 pandas 读取 CSV 文件
    data = pd.read_csv(csv_file_path)

    # 将空字符串替换为 NaN
    data['price'].replace('', np.nan, inplace=True)
    data['duration'].replace('', np.nan, inplace=True)

    # 确保 price 和 duration 列为浮点数类型
    data['price'] = data['price'].astype(float)
    data['duration'] = data['duration'].astype(float)

    # 将 NaN 替换为 None，这样在导入数据库时会被识别为 NULL
    data['price'] = data['price'].where(pd.notnull(data['price']), None)
    data['duration'] = data['duration'].where(pd.notnull(data['duration']), None)

    for index, row in data.iterrows():
        trip_instance = Trip(
            travel_company=row['travel_company'],
            area=row['area'],
            title=row['title'],
            price=row['price'],
            date=row['date'],
            departure_city=row['departure_city'],
            duration=row['duration'],
            remaining_quota=row['remaining_quota'],
            tour_schedule=row['tour_schedule'],
            url=row['url']
        )
        trip_instance.save()
    # for row in csv_reader:
    #     price_str = row['price'].replace(',', '')  # 移除逗号
    #     lion_instance = Lion(
    #         no = row['no'],
    #         company_Name = row['company_Name'],  # 通常使用小写字母加下划线的形式来命名字段
    #         area = row['area'],
    #         title = row['title'],
    #         url = row['url'],
    #         trip_type = row['trip_type'],
    #         fromDate = row['fromDate'],  # 同样使用小写字母加下划线的形式
    #         trip_number = row['trip_number'],
    #         group_total = row['group_total'],
    #         saleable = row['saleable'],
    #         after_saleable = row['after_saleable'],
    #         group_state = row['group_state'],
    #         traffic_information = row['traffic_information'],
    #         trip_information = row['trip_information'],
    #         total_Date = row['total_Date'],
    #         # price = row['price'],
    #         price = price_str,
    #         hotel = row['hotel'],)



    return HttpResponse("新增成功")

def trip_all(request):
    # # 檢查 "search" 參數是否存在
    # if "search" not in request.GET:
    #     return HttpResponseBadRequest("Missing 'search' parameter")
    # 連接到 SQLite 資料庫
    try:
        conn = sqlite3.connect(r'C:\Users\user\Desktop\trip_django\mysite\db.sqlite3')
        cursor = conn.cursor()
    except sqlite3.Error as e:
        return HttpResponseBadRequest(f"Database connection failed: {e}")


    # 安全地構建 SQL 查詢
    # search = request.GET["search"]
    try:
        # 使用 parameterized query 防止 SQL 注入
        # cursor.execute(f'SELECT {search} FROM Lion where after_saleable = "報名" ' , )
        cursor.execute(f'SELECT * FROM Lion where after_saleable = "報名" ' , )
        rows = cursor.fetchall()
    except sqlite3.Error as e:
        conn.close()
        return HttpResponseBadRequest(f"SQL query failed: {e}")

    # 關閉連線
    conn.close()

# 準備資料以供模板使用
    data = []
    no = []
    url = []
    title = []
    from_Date = []
    price = []

    for row in rows:
        data.append(row)

    for n in range(len(data)): #編號
        no.append(data[n][0])

    for t in range(len(data)): #標題
        title.append(data[t][3])

    for u in range(len(data)): #網址
        url.append(data[u][4])

    for fd in range(len(data)): #出發日期
        from_Date.append(data[fd][6])

    for p in range(len(data)): #價格
        price.append(data[p][15])

    all_data = list(zip(no, title, url, from_Date, price))

    # 渲染模板並傳遞資料
    # return render(request, "trip_all.html", {"search": search ,"all_data":all_data})
    return render(request, "trip_all.html", {"all_data":all_data})


def test(request):
    # # 獲取所有資料ORM
    # lions = Lion.objects.all()
    # res = "print all results in DB:<br>"
    # for lion in lions:
    #     res += lion.no+ ".  "+ lion.title + str(lion.price) + "<br>"
    # return HttpResponse(res)
    # # 資料庫語法
    # try:
    #     res = "print all results in DB:<br>"
    #     conn = sqlite3.connect(r'C:\Users\user\Desktop\trip_django\mysite\db.sqlite3')
    #     rows = conn.execute('SELECT * FROM Lion where after_saleable = "報名"')
    #     for row in rows:
    #         # print(row)
    #             res += str(row[1])+ "." + str(row[3]) + str(row[4]) + str(row[5]) + str(row[17]) + "<br>"
    # #     cursor = conn.cursor()
    # except sqlite3.Error as e:
    #     return HttpResponseBadRequest(f"Database connection failed: {e}")
    # conn.close()
    # return HttpResponse(res)
    try:
        res = "print all results in DB:<br>"
        conn = sqlite3.connect(r'C:\Users\user\Desktop\trip_django\mysite\db.sqlite3')
        rows = conn.execute('SELECT * FROM Lion where after_saleable = "報名" ')
        for row in rows:
            # print(row)
                res += str(row[1])+ "." + str(row[3]) + str(row[4]) + str(row[5]) + str(row[17]) + "<br>"
    #     cursor = conn.cursor()
    except sqlite3.Error as e:
        return HttpResponseBadRequest(f"Database connection failed: {e}")
    conn.close()
    return HttpResponse(res)

def item_list(request):
    city = request.GET.get("city")
    if not city:
        return HttpResponseBadRequest("Missing 'city' parameter")

    item_list = Lion.objects.filter(area=city).order_by('price')

    paginator = Paginator(item_list, 10)  # 每页显示30个项


    page_number = request.GET.get('page')

    page_obj = paginator.get_page(page_number)

    context = {
        'city':city,
        'page_obj': page_obj,

    }
    return render(request, 'item_list.html', context)


# #比價成功
def price(request):
    results_between_prices = []

    if request.method == 'POST':
        form = PriceRangeForm(request.POST)
        if form.is_valid():
            price1 = form.cleaned_data['price1']
            price2 = form.cleaned_data['price2']

            # 确保 price1 小于 price2
            if price1 > price2:
                price1, price2 = price2, price1

            results_between_prices = Lion.objects.filter(price__gt=price1, price__lt=price2)
    else:
        form = PriceRangeForm()

    return render(request, 'compare_prices.html', {
        'form': form,
        'results_between_prices': results_between_prices,
    })

def compare_prices(request): #價格區間
    results_between_prices = []

    if request.method == 'POST':
        form = PriceRangeForm(request.POST)
        if form.is_valid():
            price1 = form.cleaned_data['price1']
            price2 = form.cleaned_data['price2']

            # 确保 price1 小于 price2
            if price1 > price2:
                price1, price2 = price2, price1

            results_between_prices = Lion.objects.filter(price__gt=price1, price__lt=price2)
    else:
        form = PriceRangeForm()

    return render(request, 'front_end/home.html', {
        'form': form,
        'results_between_prices': results_between_prices,
    })

# def area(request): #地區分類
#     results_city = []
#     if request.method == 'POST':
#         form = Area(request.POST)
#         if form.is_valid():
#             city = form.cleaned_data['city']
#             results_city  = Lion.objects.filter(area=city)
#     else:
#         form = Area()

#     return render(request, 'front_end/area.html', {
#         'form': form,
#         'results_city': results_city,
#     })

# def area(request): #地區分類
#     city = request.GET["city"]
#     results_city  = Lion.objects.filter(area=city)
#     selected_options = request.POST.getlist('options')


#     selected_options_List = []

#     for options in selected_options:
#         try:
#             selected_options_List.append(int(options))
#         except ValueError:
#         # 可以在这里处理无法转换为整数的选项值
#             pass

#     results_between_prices = []
#     if request.method == 'POST':
#         form = PriceRangeForm(request.POST)
#         if form.is_valid():
#             price1 = form.cleaned_data['price1']
#             price2 = form.cleaned_data['price2']

#             # 确保 price1 小于 price2
#             if price1 > price2:
#                 price1, price2 = price2, price1
#             results_between_prices = Lion.objects.filter(area=city).filter(price__gt=price1, price__lt=price2).order_by('price')


#     else:
#         form = PriceRangeForm()
#     return render(request, 'front_end/area.html', {"city":city,'form': form,'results_city': results_city,"results_between_prices":results_between_prices,"selected_options":selected_options})



def trip_home(request):
     return render(request, 'front_end/homenew.html')



def checkbox_view(request):
    if request.method == 'POST':
        selected_options = request.POST.getlist('options')
        # 这里你可以处理选中的复选框值
        # 例如，你可以将它们打印出来或者存储在数据库中
        return HttpResponse(f"Selected options: {', '.join(selected_options)}")
    return render(request, 'test.html')


def area(request): #地區分類
    global city, current_url
    results = None
    post_page_obj = None
    if request.method == 'GET':
        #用GET抓取區域分類
        city = request.GET["city"]
        if not Lion.objects.filter(area=city):
            return HttpResponseBadRequest("Missing 'city' parameter")
        print(city)
        #用GET抓取區域分類

        #根據當前的HTTP請求擷取網址
        current_url = request.build_absolute_uri()
        print(current_url)
        #根據當前的HTTP請求擷取網址

        #初始化表單
        form = PriceRangeForm()
        selected_options = request.POST.getlist('options')
        #初始化表單

        #篩選結果
        search_result_all_item = Lion.objects.filter(area=city).exclude(price=0).order_by('price')
        #篩選結果

        # 分頁功能
        paginator = Paginator(search_result_all_item, 10)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        results = len(search_result_all_item)
        # 分頁功能

    else:
        return search_results(request)

    return render(request, 'front_end/area_result.html', {current_url:'current_url','city':city,'form': form,'form1': form1,"search_result_all_item":search_result_all_item,
                                                           "selected_options":selected_options,"results":results,
                                                           'page_obj': page_obj,'post_page_obj':post_page_obj
                                                           })


def search_results(request):
    global  selected_options, price1, price2, form, results_between_prices, current_url

    if request.method == 'POST':
        print("POST")
        # city = request.GET["city"]
        #天數表單篩選
        selected_options = request.POST.getlist('options')
        selected_options = [int(option) for option in selected_options]
        for option in selected_options:
            print(f"option:{option}")
        #天數表單篩選

        current_url = request.build_absolute_uri()
        print(current_url)

        #價格區間
        form = PriceRangeForm(request.POST)
        if form.is_valid():
            price1 = form.cleaned_data['price1']
            price2 = form.cleaned_data['price2']
            # day = form.cleaned_data['day']
        #價格區間

        # 确保 price1 小于 price2
        if price1 > price2:
            price1, price2 = price2, price1
        results_between_prices = Lion.objects.filter(area=city).filter(price__gt=price1, price__lt=price2).order_by('price')


    results = len(results_between_prices)


    if request.method == 'GET':
        # form = PriceRangeForm()
        current_url = request.build_absolute_uri()
        print(current_url)


    # 分頁功能
    paginator = Paginator(results_between_prices, 10)
    post_page_number = request.GET.get('page')
    post_page_obj = paginator.get_page(post_page_number)
    # 分頁功能


    return render(request, 'front_end/search_result.html', {'city':city,'form': form,"results_between_prices":results_between_prices,
                                                           "selected_options":selected_options,"results":results,
                                                           'post_page_obj':post_page_obj
                                                           })


def add_to_itinerary(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        price = request.POST.get('price')
        print(title)
        print(price)
        # 做一些檢查和處理，然後將資料儲存到資料庫
        Lion_save.objects.create(title=title, price=price)
        print(current_url)
        return redirect(current_url)
    else:
        return HttpResponse('僅接受POST請求')

def personal_page(request):
    results = Lion_save.objects.order_by('price')

    return render(request, 'front_end/personal.html', {'results':results})
