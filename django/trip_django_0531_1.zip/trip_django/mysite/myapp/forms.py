# forms.py
from django import forms

class PriceRangeForm(forms.Form):
    price1 = forms.IntegerField(label='最低價格', min_value=10, max_value=100000)
    price2 = forms.IntegerField(label='最高價格', min_value=100, max_value=1000000)


class Area(forms.Form):
    city = forms.CharField(label='地區',max_length=10, required=True)