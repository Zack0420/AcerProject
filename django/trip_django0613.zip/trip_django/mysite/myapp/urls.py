"""
URL configuration for mysite project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from myapp import views
from django.urls import re_path as url


urlpatterns = [
    path('hello/', views.hello),
    # url(r'^hello/(\d+)/', views.hello),
    path('number_show/', views.number_show),
    path('bmi/', views.bmi),
    path('hello_render/', views.hello_render),
    path('bmi_render/', views.bmi_render),
    path('bmi_render_locals/', views.bmi_render_locals),
    path('bmi/', views.bmi),
    path('nine_nine_table/', views.nine_nine_table),
    path('trip_all/', views.trip_all),
    path('import_data_from_csv/', views.import_data_from_csv),
    path('test/', views.test),
    path('price/', views.price),
    path('compare-prices/', views.compare_prices),
    path('area/', views.area,name='area'),
    path('trip_home/', views.trip_home),
    path('checkbox_view/', views.checkbox_view),
    path('items/', views.item_list, name='item_list'),
    path('search_results/', views.search_results, name='search_results'),
    path('add_to_itinerary/', views.add_to_itinerary, name='add_to_itinerary'),
    path('personal_page/', views.personal_page, name='personal_page'),


]




