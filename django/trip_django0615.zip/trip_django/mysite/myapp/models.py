from django.db import models


class Lion(models.Model):
    no = models.TextField()
    company_Name = models.TextField()
    area = models.CharField(max_length=10)
    title = models.TextField()
    url = models.TextField()
    trip_type = models.TextField()
    fromDate = models.TextField()
    trip_number =models.TextField()
    group_total = models.TextField()
    saleable = models.TextField()
    after_saleable = models.TextField()
    group_state = models.TextField()
    traffic_information = models.TextField()
    trip_information = models.TextField()
    total_Date = models.IntegerField(null=True)
    price = models.IntegerField()
    hotel = models.TextField()
    class Meta:
        db_table = "Lion"

class Lion_save(models.Model):
    no = models.TextField()
    company_Name = models.TextField()
    area = models.CharField(max_length=10)
    title = models.TextField(blank=True,null=True)
    url = models.TextField()
    trip_type = models.TextField()
    fromDate = models.TextField()
    trip_number =models.TextField()
    group_total = models.TextField()
    saleable = models.TextField()
    after_saleable = models.TextField()
    group_state = models.TextField()
    traffic_information = models.TextField()
    trip_information = models.TextField()
    total_Date = models.IntegerField(null=True)
    price = models.IntegerField()
    hotel = models.TextField()
    class Meta:
        db_table = "Lion_save"


class Trip(models.Model):
    id = models.AutoField(primary_key=True)
    travel_company = models.TextField()
    area = models.TextField()
    title = models.TextField()
    price = models.IntegerField(null=True)
    date = models.TextField()
    departure_city = models.TextField()
    duration = models.IntegerField(null=True)
    remaining_quota = models.TextField()
    tour_schedule =models.TextField()
    url = models.TextField()

    class Meta:
        db_table = "Trip"

# class User_save(models.Model):
#     name = models.TextField()
#     travel_company = models.TextField()
#     area = models.TextField()
#     title = models.TextField()
#     price = models.IntegerField(null=True)
#     date = models.TextField()
#     departure_city = models.TextField()
#     duration = models.IntegerField(null=True)
#     remaining_quota = models.TextField()
#     tour_schedule =models.TextField()
#     url = models.TextField()
#     class Meta:
#         db_table = "User_save"
