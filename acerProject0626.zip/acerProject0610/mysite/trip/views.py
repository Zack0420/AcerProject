from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.http import HttpResponse
from django.http import HttpResponseBadRequest
from django.core.paginator import Paginator
from .models import Trip, User_save
from member.models import Member
from .forms import PersonalPageForm, PeriodForm
from datetime import datetime
import pandas as pd
import numpy as np
from django.template.loader import get_template
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
import datetime
from dateutil.relativedelta import *



# Create your views here.

#csv轉db
def import_data_from_csv(request):
    # csv_file_path = r'C:\Users\user\Desktop\trip_django\mysite\csv\all.csv'
    # csv_file_path = r"C:\Users\user\Desktop\trip_django\mysite\csv\DomesticTravelInfo.csv"
    # csv_file_path = r"C:\Users\user\Desktop\trip_django\mysite\csv\lifetour_search.csv"
    # csv_file_path = r"C:\Users\user\Desktop\trip_django\mysite\csv\liontrip.csv"

    csv_file_path = [r"/app/mysite/trip/csv/combined/2024-06-18_combined_data.csv",]
    for i in csv_file_path:
        data = pd.read_csv(i,encoding="UTF-8")

        data['price'] = data['price'].copy().replace(np.nan, None)
        data['duration'] = data['duration'].copy().replace(np.nan, None)

        for index, row in data.iterrows():
            trip_instance = Trip(
                travel_company=row['travel_company'],
                area=row['area'],
                title=row['title'],
                price=row['price'],
                date=row['date'],
                departure_city=row['departure_city'],
                duration=row['duration'],
                remaining_quota=row['remaining_quota'],
                tour_schedule=row['tour_schedule'],
                url=row['url']
            )
            trip_instance.save()


    return HttpResponse("新增成功")





def trip_home(request):
    if "username" not in request.COOKIES.keys():
        if request.method == 'POST':
            keyword = request.POST.get('keyword')
            origin = request.POST.get('origin')
            startDate = request.POST.get('startDate')
            duration = request.POST.get('duration')
            travelArea = request.POST.getlist('travelArea')
            min_price = request.POST.get('min_price')
            max_price = request.POST.get('max_price')

            items = Trip.objects.all().order_by('price').exclude(price=None)
            if keyword:
                items = items.filter(title__icontains=keyword)

            if origin:
                items = items.filter(departure_city__icontains=origin)

            if startDate:
                try:
                    # 將日期從 YYYY-MM-DD 轉換為 YYYY/MM/DD 格式
                    start_date_obj = datetime.strptime(startDate, "%Y-%m-%d")
                    formatted_start_date = start_date_obj.strftime("%Y/%m/%d")
                    items = items.filter(date=formatted_start_date)
                except ValueError:
                    return HttpResponse("日期格式錯誤，請使用 YYYY-MM-DD 格式")

            if duration:
                items = items.filter(duration=duration)

            #價格比較
            if min_price:
                items = items.filter(price__gte=min_price)

            if max_price:
                items = items.filter(price__lte=max_price)
            #價格比較

            if travelArea:
                items = items.filter(area__in=travelArea)
            # return area(request, items)
            request.session['select_items'] = list(items.values())
            return redirect ("area")

        return render(request, 'trip/home.html', {'items': items})

    else:
        if request.method == 'POST':
            username = request.COOKIES.get('username')
            keyword = request.POST.get('keyword')
            origin = request.POST.get('origin')
            startDate = request.POST.get('startDate')
            duration = request.POST.get('duration')
            travelArea = request.POST.getlist('travelArea')
            min_price = request.POST.get('min_price')
            max_price = request.POST.get('max_price')

            items = Trip.objects.all().order_by('price').exclude(price=None)
            if keyword:
                items = items.filter(title__icontains=keyword)

            if origin:
                items = items.filter(departure_city__icontains=origin)

            if startDate:
                try:
                    # 將日期從 YYYY-MM-DD 轉換為 YYYY/MM/DD 格式
                    start_date_obj = datetime.strptime(startDate, "%Y-%m-%d")
                    formatted_start_date = start_date_obj.strftime("%Y/%m/%d")
                    items = items.filter(date=formatted_start_date)
                except ValueError:
                    return HttpResponse("日期格式錯誤，請使用 YYYY-MM-DD 格式")

            if duration:
                items = items.filter(duration=duration)

            #價格比較
            if min_price:
                items = items.filter(price__gte=min_price)

            if max_price:
                items = items.filter(price__lte=max_price)
            #價格比較

            if travelArea:
                items = items.filter(area__in=travelArea)
            # return area(request, items)
            request.session['select_items'] = list(items.values())
            return redirect ("area")
        return render(request, 'trip/index.html', {'items': items})



def area(request):
    username = None
    results = None
    post_page_obj = None
    global current_url
    current_url = "{% url 'area'%}"

    if "username" not in request.COOKIES.keys():
        if request.method == 'POST':
            keyword = request.POST.get('keyword')
            travel_company = request.POST.get('travel_company')
            origin = request.POST.get('origin')
            startDate = request.POST.get('startDate')
            duration = request.POST.get('duration')
            travelArea = request.POST.getlist('travelArea')
            min_price = request.POST.get('min_price')
            max_price = request.POST.get('max_price')

            if travel_company:
                items = items.filter(travel_company__icontains=travel_company)

            items = Trip.objects.all().order_by('price').exclude(price=None)
            if keyword:
                items = items.filter(title__icontains=keyword)

            if origin:
                items = items.filter(departure_city__icontains=origin)

            if startDate:
                try:
                    # 將日期從 YYYY-MM-DD 轉換為 YYYY/MM/DD 格式
                    start_date_obj = datetime.datetime.strptime(startDate, "%Y-%m-%d")
                    formatted_start_date = start_date_obj.strftime("%Y/%m/%d")
                    items = items.filter(date=formatted_start_date)
                except ValueError:
                    return HttpResponse("日期格式錯誤，請使用 YYYY-MM-DD 格式")

            if duration:
                items = items.filter(duration=duration)

            #價格比較
            if min_price:
                items = items.filter(price__gte=min_price)

            if max_price:
                items = items.filter(price__lte=max_price)
            #價格比較

            if travelArea:
                items = items.filter(area__in=travelArea)
            # return area(request, items)
            request.session['select_items'] = list(items.values())
            return redirect ("area")
    else:
        if request.method == 'POST':
            keyword = request.POST.get('keyword')
            origin = request.POST.get('origin')
            startDate = request.POST.get('startDate')
            duration = request.POST.get('duration')
            travelArea = request.POST.getlist('travelArea')
            min_price = request.POST.get('min_price')
            max_price = request.POST.get('max_price')

            items = Trip.objects.all().order_by('price').exclude(price=None)
            if keyword:
                items = items.filter(title__icontains=keyword)

            if origin:
                items = items.filter(departure_city__icontains=origin)

            if startDate:
                try:
                    # 將日期從 YYYY-MM-DD 轉換為 YYYY/MM/DD 格式
                    start_date_obj = datetime.datetime.strptime(startDate, "%Y-%m-%d")
                    formatted_start_date = start_date_obj.strftime("%Y/%m/%d")
                    items = items.filter(date=formatted_start_date)
                except ValueError:
                    return HttpResponse("日期格式錯誤，請使用 YYYY-MM-DD 格式")

            if duration:
                items = items.filter(duration=duration)

            #價格比較
            if min_price:
                items = items.filter(price__gte=min_price)

            if max_price:
                items = items.filter(price__lte=max_price)
            #價格比較

            if travelArea:
                items = items.filter(area__in=travelArea)
            # return area(request, items)
            request.session['select_items'] = list(items.values())
            return redirect ("area")

        username = request.COOKIES["username"]


    items = request.session.get('select_items')


    # #根據當前的HTTP請求擷取網址
    current_url = request.build_absolute_uri()
    # #根據當前的HTTP請求擷取網址

    #篩選結果
    search_result_all_item = items
    #篩選結果

    # 分頁功能
    paginator = Paginator(search_result_all_item, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    results = len(search_result_all_item)


    return render(request, 'trip/area_result.html', {"items":items,'current_url':current_url,"search_result_all_item":search_result_all_item,
                                                           "results":results,
                                                           'page_obj': page_obj,'post_page_obj':post_page_obj, "username": username,
                                                           })





def add_to_itinerary(request):
    # #根據當前的HTTP請求擷取網址
    if "username" not in request.COOKIES.keys():

        return render(request, "member/home.html")

    if request.method == 'POST':
        username = request.COOKIES.get('username')
        travel_company = request.POST.get('travel_company')
        title = request.POST.get('title')
        departure_city = request.POST.get('departure_city')
        date = request.POST.get('date')
        duration = request.POST.get('duration')
        area = request.POST.get('area')
        price = request.POST.get('price')
        url = request.POST.get('url')
        tour_schedule = request.POST.get('tour_schedule')
        remaining_quota = request.POST.get('remaining_quota')

        # 做一些檢查和處理，然後將資料儲存到資料庫
        User_save.objects.create(username=username, title=title, price=price, travel_company=travel_company,
                                 departure_city=departure_city, date=date,duration=duration,
                                 area=area, url=url, tour_schedule=tour_schedule, remaining_quota=remaining_quota)
        return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        return HttpResponse('僅接受POST請求')

def personal_page(request):

    if "username" in request.COOKIES.keys():
        username = request.COOKIES['username']
        results = User_save.objects.filter(username = username).order_by('date')
        verification = request.COOKIES['verification']
        data = []
        for i in results:
            plan = {}
            plan['username'] = i.username
            plan['title'] = i.title
            plan['travel_company'] = i.travel_company
            plan['area'] = i.area
            plan['price'] = i.price
            plan['date'] = i.date
            plan['departure_city'] = i.departure_city
            plan['duration'] = i.duration
            plan['remaining_quota'] = i.remaining_quota
            plan['url'] = i.url
            plan['days'] = []

            for key, value in eval(i.tour_schedule).items():
                temp = {}
                temp['day'] = key
                temp['schedule'] = list(value['schedule'])
                temp['hotel'] = list(value['possible_hotel'])
                plan['days'].append(temp)

            data.append(plan)

        return render(request, 'trip/personal_schedule.html', {"data": data, 'verification':verification, "username": username})

    else:

        return redirect('loginForm')





def user_save_delete(request):

    if request.method == "POST":

        personalForm = PersonalPageForm(request.POST)

        if personalForm.is_valid():

            username = personalForm.cleaned_data['username']
            title = personalForm.cleaned_data['title']
            company = personalForm.cleaned_data['company']
            date = personalForm.cleaned_data['date']

            plan = User_save.objects.filter(username = username, title = title, travel_company = company, date = date)

            for i in plan:
                User_save.objects.get(id =i.id).delete()

        else:

            personalForm = PersonalPageForm()

    return redirect("personal_page")

def sendemail(request):

    if request.method == "POST":
        personalForm = PersonalPageForm(request.POST)
        if personalForm.is_valid():
            username = personalForm.cleaned_data['username']
            title = personalForm.cleaned_data['title']
            company = personalForm.cleaned_data['company']
            date = personalForm.cleaned_data['date']
            print(username, repr(title), company, date)

            data = User_save.objects.filter(username = username,travel_company = company, date = date, title = title)
            data = data[0]
            plan = {}
            plan['username'] = data.username
            plan['title'] = data.title
            plan['travel_company'] = data.travel_company
            plan['area'] = data.area
            plan['price'] = data.price
            plan['date'] = data.date
            plan['departure_city'] = data.departure_city
            plan['duration'] = data.duration
            plan['remaining_quota'] = data.remaining_quota
            plan['url'] = data.url
            plan['days'] = []

            for key, value in eval(data.tour_schedule).items():
                temp = {}
                temp['day'] = key
                temp['schedule'] = list(value['schedule'])
                temp['hotel'] = list(value['possible_hotel'])
                plan['days'].append(temp)

            emailto = Member.objects.get(username = username).email

            subject, from_email, to = 'Welcome to app', '2024acergroup1@gmail.com', emailto
            text_content = '你的行程資訊'

            html_content = render_to_string('trip/email.html', {'plan':plan})
            msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
            msg.attach_alternative(html_content, "text/html")
            msg.send()

        else:

            personalForm = PersonalPageForm()

    return redirect("personal_page")

def period_changed(request):

    if "username" in request.COOKIES.keys():
        if request.method == "POST":
            periodForm = PeriodForm(request.POST)
            if periodForm.is_valid():
                period = periodForm.cleaned_data['period']
                username = request.COOKIES['username']
                today = datetime.datetime.now().strftime("%Y/%m/%d")
                dt = datetime.datetime.strptime(today, "%Y/%m/%d")
                results = User_save.objects.filter(username = username).order_by('date')

                if period == "一周內":

                    after_a_week = dt + relativedelta(days =+7)
                    list_range = []

                    for n, i in enumerate(results):
                        data_date = datetime.datetime.strptime(i.date, "%Y/%m/%d")
                        if data_date < after_a_week and data_date >= dt:
                            list_range.append(n)

                    if len(list_range) == 0:
                        results = []
                    else:
                        results = results[list_range[0]:list_range[-1]+1]


                elif period == "一個月內":

                    after_a_month = dt + relativedelta(months =+1)
                    list_range = []

                    for n, i in enumerate(results):
                        data_date = datetime.datetime.strptime(i.date, "%Y/%m/%d")
                        if data_date < after_a_month and data_date >= dt:
                            list_range.append(n)

                    if len(list_range) == 0:
                        results = []
                    else:
                        results = results[list_range[0]:list_range[-1]+1]

                elif period == "一年內":

                    after_a_year = dt + relativedelta(years =+1)
                    list_range = []

                    for n, i in enumerate(results):
                        data_date = datetime.datetime.strptime(i.date, "%Y/%m/%d")
                        if data_date < after_a_year and data_date >= dt:
                            list_range.append(n)

                    if len(list_range) == 0:
                        results = []
                    else:
                        results = results[list_range[0]:list_range[-1]+1]

                data = []
                for i in results:
                    plan = {}
                    plan['username'] = i.username
                    plan['title'] = i.title
                    plan['travel_company'] = i.travel_company
                    plan['area'] = i.area
                    plan['price'] = i.price
                    plan['date'] = i.date
                    plan['departure_city'] = i.departure_city
                    plan['duration'] = i.duration
                    plan['remaining_quota'] = i.remaining_quota
                    plan['url'] = i.url
                    plan['days'] = []

                    for key, value in eval(i.tour_schedule).items():
                        temp = {}
                        temp['day'] = key
                        temp['schedule'] = list(value['schedule'])
                        temp['hotel'] = list(value['possible_hotel'])
                        plan['days'].append(temp)

                    data.append(plan)

                return render(request, 'trip/personal_schedule.html', {"data": data})
            else:

                periodForm = PeriodForm()

    else:

        return redirect('login')

