# forms.py
from django import forms
from .models import Lion_save

class PriceRangeForm(forms.Form):
    price1 = forms.IntegerField(label='最低價格', min_value=10, max_value=100000, )#required=False
    price2 = forms.IntegerField(label='最高價格', min_value=100, max_value=1000000)#required=False
    # day = forms.IntegerField(label='天數',min_value=1, max_value=100)



class Area(forms.Form):
    city = forms.CharField(label='地區',max_length=10, required=True)

class Day(forms.Form):
    day = forms.IntegerField(label='天數',min_value=1, max_value=100)

class submitForm(forms.ModelForm):
    class Meta:
        model = Lion_save
        fields = ['no','company_Name', 'area','title',
                  'url','trip_type', 'fromDate', 'trip_number','group_total',
                  'saleable','after_saleable','group_state','traffic_information',
                  'trip_information','total_Date','price','hotel']


# class submitForm(forms.ModelForm):
#     class Meta:
#         model = User_save
#         fields = ['travel_company','area','title', 'price',
#                   'date','departure_city', 'duration', 'remaining_quota',
#                   'tour_schedule','url']


