from django.db import models


class Lion(models.Model):
    no = models.TextField()
    company_Name = models.TextField()
    area = models.CharField(max_length=10)
    title = models.TextField()
    url = models.TextField()
    trip_type = models.TextField()
    fromDate = models.TextField()
    trip_number =models.TextField()
    group_total = models.TextField()
    saleable = models.TextField()
    after_saleable = models.TextField()
    group_state = models.TextField()
    traffic_information = models.TextField()
    trip_information = models.TextField()
    total_Date = models.IntegerField()
    price = models.IntegerField()
    hotel = models.TextField()
    class Meta:
        db_table = "Lion"


