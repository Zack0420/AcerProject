# forms.py
from django import forms


class PersonalPageForm(forms.Form):
    username = forms.CharField(max_length=50, label="username")
    title = forms.CharField(max_length=100, label="title")
    company = forms.CharField(max_length=256, label="company")
    date = forms.CharField(max_length = 50, label="date")

    def clean_username(self):

        username = self.cleaned_data.get("username")

        return username
    def clean_title(self):

        title = self.cleaned_data.get("title")
        return title+"\r\n"

    def clean_company(self):

        company = self.cleaned_data.get("company")

        return company
    def clean_date(self):

        date = self.cleaned_data.get("date")

        return date

class PeriodForm(forms.Form):

    period = forms.CharField(max_length=50, label="period")


    def clean_peroid(self):

        period = self.cleaned_data.get('period')

        return period