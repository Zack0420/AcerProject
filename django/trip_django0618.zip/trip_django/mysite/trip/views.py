from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.http import HttpResponse
from django.http import HttpResponseBadRequest
from django.core.paginator import Paginator
from .models import Trip, User_save
# from .forms import PriceRangeForm
from datetime import datetime
import pandas as pd
import numpy as np




# Create your views here.

#csv轉db
def import_data_from_csv(request):
    # csv_file_path = r'C:\Users\user\Desktop\trip_django\mysite\csv\all.csv'
    # csv_file_path = r"C:\Users\user\Desktop\trip_django\mysite\csv\DomesticTravelInfo.csv"
    # csv_file_path = r"C:\Users\user\Desktop\trip_django\mysite\csv\lifetour_search.csv"
    # csv_file_path = r"C:\Users\user\Desktop\trip_django\mysite\csv\liontrip.csv"
    csv_file_path = [r"C:\Users\user\Desktop\trip_django\mysite\csv\liontrip.csv",
                     r"C:\Users\user\Desktop\trip_django\mysite\csv\lifetour_search.csv",
                     r"C:\Users\user\Desktop\trip_django\mysite\csv\DomesticTravelInfo.csv"]
    for i in csv_file_path:

    # 使用 pandas 读取 CSV 文件
        data = pd.read_csv(i)

        # 将空字符串替换为 NaN
        data['price'].replace('額滿', np.nan, inplace=True)
        data['price'].replace('', np.nan, inplace=True)
        data['duration'].replace('', np.nan, inplace=True)

        # 确保 price 和 duration 列为浮点数类型
        data['price'] = data['price'].astype(float)
        data['duration'] = data['duration'].astype(float)

        # 将 NaN 替换为 None，这样在导入数据库时会被识别为 NULL
        data['price'] = data['price'].where(pd.notnull(data['price']), None)
        data['duration'] = data['duration'].where(pd.notnull(data['duration']), None)

        for index, row in data.iterrows():
            trip_instance = Trip(
                travel_company=row['travel_company'],
                area=row['area'],
                title=row['title'],
                price=row['price'],
                date=row['date'],
                departure_city=row['departure_city'],
                duration=row['duration'],
                remaining_quota=row['remaining_quota'],
                tour_schedule=row['tour_schedule'],
                url=row['url']
            )
            trip_instance.save()


    return HttpResponse("新增成功")




def trip_home(request):
    if request.method == 'POST':
        keyword = request.POST.get('keyword')
        origin = request.POST.get('origin')
        startDate = request.POST.get('startDate')
        duration = request.POST.get('duration')
        travelArea = request.POST.getlist('travelArea')
        min_price = request.POST.get('min_price')
        max_price = request.POST.get('max_price')

        items = Trip.objects.all().order_by('price').exclude(price=None)
        if keyword:
            items = items.filter(title__icontains=keyword)

        if origin:
            items = items.filter(departure_city__icontains=origin)

        if startDate:
            try:
                # 將日期從 YYYY-MM-DD 轉換為 YYYY/MM/DD 格式
                start_date_obj = datetime.strptime(startDate, "%Y-%m-%d")
                formatted_start_date = start_date_obj.strftime("%Y/%m/%d")
                items = items.filter(date=formatted_start_date)
            except ValueError:
                return HttpResponse("日期格式錯誤，請使用 YYYY-MM-DD 格式")

        if duration:
            items = items.filter(duration=duration)

        #價格比較
        if min_price:
            items = items.filter(price__gte=min_price)

        if max_price:
            items = items.filter(price__lte=max_price)
        #價格比較

        if travelArea:
            items = items.filter(area__in=travelArea)
        # return area(request, items)
        request.session['select_items'] = list(items.values())
        return redirect ("area")


    else:
        items = None

    return render(request, 'front_end/home.html', {'items': items})


def area(request):
    # global city, current_url
    global current_url, selected_options
    results = None
    post_page_obj = None


    if request.method == 'POST':
        keyword = request.POST.get('keyword')
        origin = request.POST.get('origin')
        startDate = request.POST.get('startDate')
        duration = request.POST.get('duration')
        travelArea = request.POST.getlist('travelArea')
        min_price = request.POST.get('min_price')
        max_price = request.POST.get('max_price')

        items = Trip.objects.all().order_by('price').exclude(price=None)
        if keyword:
            items = items.filter(title__icontains=keyword)

        if origin:
            items = items.filter(departure_city__icontains=origin)

        if startDate:
            try:
                # 將日期從 YYYY-MM-DD 轉換為 YYYY/MM/DD 格式
                start_date_obj = datetime.strptime(startDate, "%Y-%m-%d")
                formatted_start_date = start_date_obj.strftime("%Y/%m/%d")
                items = items.filter(date=formatted_start_date)
            except ValueError:
                return HttpResponse("日期格式錯誤，請使用 YYYY-MM-DD 格式")

        if duration:
            items = items.filter(duration=duration)

        #價格比較
        if min_price:
            items = items.filter(price__gte=min_price)

        if max_price:
            items = items.filter(price__lte=max_price)
        #價格比較

        if travelArea:
            items = items.filter(area__in=travelArea)
        # return area(request, items)
        request.session['select_items'] = list(items.values())
        return redirect ("area")


    items = request.session.get('select_items')


    # #根據當前的HTTP請求擷取網址
    current_url = request.build_absolute_uri()
    print(current_url)
    # #根據當前的HTTP請求擷取網址




    #篩選結果
    search_result_all_item = items
    #篩選結果

    # 分頁功能
    paginator = Paginator(search_result_all_item, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    results = len(search_result_all_item)


    return render(request, 'front_end/area_result.html', {"items":items,'current_url':current_url,"search_result_all_item":search_result_all_item,
                                                           "results":results,
                                                           'page_obj': page_obj,'post_page_obj':post_page_obj
                                                           })


# def search_results(request):
#     global  price1, price2, form, results_between_prices, current_url

#     results_between_prices = request.session.get('select_items')


#     if request.method == 'POST':
#         print("POST")
#         # city = request.GET["city"]
#         #天數表單篩選
#         selected_options = request.POST.getlist('options')
#         selected_options = [int(option) for option in selected_options]
#         for option in selected_options:
#             print(f"option:{option}")
#         #天數表單篩選

#         current_url = request.build_absolute_uri()
#         print(current_url)

#         #價格區間
#         form = PriceRangeForm(request.POST)
#         if form.is_valid():
#             price1 = form.cleaned_data['price1']
#             price2 = form.cleaned_data['price2']
#             # day = form.cleaned_data['day']
#         #價格區間

#         # 确保 price1 小于 price2
#         if price1 > price2:
#             price1, price2 = price2, price1
#         results_between_prices = Trip.objects.all().filter(price__gt=price1, price__lt=price2).order_by('price')
#     results = len(results_between_prices)


#     if request.method == 'GET':
#         form = PriceRangeForm()
#         selected_options = request.POST.getlist('options')
#         current_url = request.build_absolute_uri()
#         print(current_url)


#     # 分頁功能
#     paginator = Paginator(results_between_prices, 10)
#     post_page_number = request.GET.get('page')
#     post_page_obj = paginator.get_page(post_page_number)
#     # 分頁功能


#     return render(request, 'trip/search_result.html', {'form': form,"results_between_prices":results_between_prices,
#                                                            "selected_options":selected_options,"results":results,
#                                                            'post_page_obj':post_page_obj
#                                                            })


def add_to_itinerary(request):
    if "username" not in request.COOKIES.keys():

        return render(request, "/home.html")

    if request.method == 'POST':
        travel_company = request.POST.get('travel_company')
        title = request.POST.get('title')
        departure_city = request.POST.get('departure_city')
        date = request.POST.get('date')
        duration = request.POST.get('duration')
        area = request.POST.get('area')
        price = request.POST.get('price')
        url = request.POST.get('url')
        tour_schedule = request.POST.get('tour_schedule')
        remaining_quota = request.POST.get('remaining_quota')

        # 做一些檢查和處理，然後將資料儲存到資料庫
        User_save.objects.create(title=title, price=price, travel_company=travel_company,
                                 departure_city=departure_city, date=date,duration=duration,
                                 area=area, url=url, tour_schedule=tour_schedule, remaining_quota=remaining_quota)
        # print(current_url)
        return redirect(current_url)
    else:
        return HttpResponse('僅接受POST請求')

def delete_from_itinerary(request):
    if "username" not in request.COOKIES.keys():
        return render(request, "member/home.html")

    if request.method == 'POST':
        item_id = request.POST.get('id')
        if item_id:
            item = get_object_or_404(User_save, id=item_id)
            item.delete()
            # print(current_url)
            return redirect("http://127.0.0.1:8000/myapp/personal_page/")
    else:
        return HttpResponse('僅接受POST請求')


def personal_page(request):
    if "username" not in request.COOKIES.keys():
        return render(request, "member/home.html")

    results = User_save.objects.order_by('price')
    if request.method == 'POST':
        travel_company = request.POST.get('travel_company')
        title = request.POST.get('title')
        departure_city = request.POST.get('departure_city')
        date = request.POST.get('date')
        duration = request.POST.get('duration')
        area = request.POST.get('area')
        price = request.POST.get('price')
        url = request.POST.get('url')
        tour_schedule = request.POST.get('tour_schedule')
        remaining_quota = request.POST.get('remaining_quota')
        # Lion_save.delete(title=title, price=price)

        User_save.delete(title=title, price=price, travel_company=travel_company,
                                 departure_city=departure_city, date=date,duration=duration,
                                 area=area, url=url, tour_schedule=tour_schedule, remaining_quota=remaining_quota)
        print(current_url)
        return redirect(current_url)
    # else:
    #     return HttpResponse('僅接受POST請求')

    return render(request, 'front_end/personal_schedule.html', {'results':results})


